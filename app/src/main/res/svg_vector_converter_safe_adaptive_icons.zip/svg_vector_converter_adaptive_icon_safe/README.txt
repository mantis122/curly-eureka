Safe adaptive launcher icon package.

This version fixes clipping on Samsung/One UI by adding more foreground padding.

Install:
1. Copy app/src/main/res/ into your project's app/src/main/res/.
2. Replace existing launcher icon files.
3. Make sure AndroidManifest.xml contains:
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"

If the old cropped icon remains, uninstall the app completely, then reinstall.
